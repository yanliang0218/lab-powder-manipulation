#!/usr/bin/env python3

# ==============================================================================
# Project: ROS 2 Eye-in-Hand Calibration
# File: webcam_handeye_720p_150hz.launch.py
# Author: Lang Yun
# Purpose:
#     Start the high-rate online data-acquisition path used before offline
#     AprilTag detection and hand-eye calibration.
# Description:
#     This launch file starts usb_cam as the only camera/image publisher and
#     starts sensor_sync to package each unique compressed image with the latest
#     robot FK pose. No AprilTag detection is performed in the online path.
# ==============================================================================

"""Launch the online acquisition path for offline eye-in-hand calibration.

usb_cam is the only image publisher. sensor_sync packages each unique
compressed image with the latest FK pose. AprilTag detection and hand-eye
calibration are intentionally performed later from the recorded /synced_msg
rosbag, so they cannot reduce the camera publication rate.

The requested 1280x720 at 150 Hz mode is a hardware/driver request and must be
supported by the selected camera mode.
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    """Create the ROS 2 launch description for camera capture and data packing."""

    # LaunchConfiguration objects hold values supplied on the command line.
    # Example:
    #   ros2 launch arm_v2_description webcam_handeye_720p_150hz.launch.py \
    #       video_device:=/dev/video3 framerate:=150.0
    video_device = LaunchConfiguration("video_device")
    image_width = LaunchConfiguration("image_width")
    image_height = LaunchConfiguration("image_height")
    framerate = LaunchConfiguration("framerate")
    pixel_format = LaunchConfiguration("pixel_format")

    # Declare user-adjustable camera settings and their default values.
    # These values request a camera mode; the physical camera and V4L2 driver
    # must actually support the selected resolution, format and frame rate.
    arguments = [
        DeclareLaunchArgument(
            "video_device",
            default_value="/dev/video0",
        ),
        DeclareLaunchArgument(
            "image_width",
            default_value="1280",
        ),
        DeclareLaunchArgument(
            "image_height",
            default_value="720",
        ),
        DeclareLaunchArgument(
            "framerate",
            default_value="150.0",
        ),
        DeclareLaunchArgument(
            "pixel_format",
            default_value="mjpeg2rgb",
            description=(
                "Must be supported by both the camera and usb_cam. "
                "Run usb_cam with pixel_format:=test to list driver formats."
            ),
        ),
    ]

    # --------------------------------------------------------------------------
    # Node 1: usb_cam
    # --------------------------------------------------------------------------
    # usb_cam owns the physical camera. It captures each frame and publishes it
    # under the /webcam namespace. No custom OpenCV VideoCapture driver is used.
    camera = Node(
        package="usb_cam",
        executable="usb_cam_node_exe",
        namespace="webcam",
        name="usb_cam",
        output="screen",
        parameters=[
            {
                # Linux V4L2 camera device, for example /dev/video0 or /dev/video3.
                "video_device": video_device,

                # Memory-mapped V4L2 buffers normally provide efficient capture.
                "io_method": "mmap",

                # mjpeg2rgb requests MJPEG from the USB camera and decodes it to
                # a ROS raw image. The compressed image_transport plugin can then
                # provide /webcam/image_raw/compressed for sensor_sync.
                "pixel_format": pixel_format,

                # ParameterValue enforces the data types expected by usb_cam.
                "image_width": ParameterValue(
                    image_width,
                    value_type=int,
                ),
                "image_height": ParameterValue(
                    image_height,
                    value_type=int,
                ),
                "framerate": ParameterValue(
                    framerate,
                    value_type=float,
                ),

                # camera_name identifies the camera; frame_id identifies the
                # optical data in ROS message headers and the TF frame tree.
                "camera_name": "webcam",
                "frame_id": "webcam_frame",
            }
        ],
    )

    # --------------------------------------------------------------------------
    # Node 2: sensor_sync
    # --------------------------------------------------------------------------
    # sensor_sync subscribes to compressed images, FK and optional joint angles.
    # Every unique image is packaged with the latest FK pose and published as a
    # SyncedMsg. AprilTag detection is deliberately deferred to the offline tool.
    sync = Node(
        package="arm_v2_description",
        executable="sensor_sync",
        name="sensor_sync",
        output="screen",
        parameters=[
            {
                # Robot reference frame used to describe the FK pose.
                "frame": "base_link",

                # Input topics produced by the FK and encoder-related nodes.
                "fk_topic": "/FK_pose",
                "joint_angles_topic": "/joint_angles",

                # Compressed image input and packaged-data output topics.
                "image_topic": "/webcam/image_raw/compressed",
                "synced_topic": "/synced_msg",
            }
        ],
    )

    # Launch arguments are registered first, followed by the two online nodes.
    return LaunchDescription(arguments + [camera, sync])
